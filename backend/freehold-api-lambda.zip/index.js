// Simplified Lambda function for AWS deployment
const express = require('express');
const cors = require('cors');
const serverless = require('serverless-http');

const app = express();

// Enable CORS
app.use(cors({
  origin: ['https://main.amplifyapp.com', 'https://*.amplifyapp.com', 'http://localhost:3000'],
  credentials: true
}));

app.use(express.json());

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// Mock authentication endpoint
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  
  // Simple mock authentication
  if (email === 'admin@freehold.com' && password === 'password123') {
    res.json({
      token: 'mock-jwt-token-' + Date.now(),
      refreshToken: 'mock-refresh-token-' + Date.now(),
      user: {
        id: '1',
        email: email,
        firstName: 'Admin',
        lastName: 'User',
        role: 'admin'
      }
    });
  } else {
    res.status(401).json({
      error: {
        code: 'INVALID_CREDENTIALS',
        message: 'Invalid email or password'
      }
    });
  }
});

// Mock token validation
app.get('/api/auth/validate', (req, res) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer mock-jwt-token')) {
    res.json({ valid: true });
  } else {
    res.status(401).json({ error: 'Invalid token' });
  }
});

// Mock categories endpoint
app.get('/api/categories', (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer mock-jwt-token')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  res.json([
    {
      id: '1',
      name: 'Meeting Minutes',
      description: 'Board meeting minutes and agendas',
      documentCount: 5,
      createdAt: new Date().toISOString()
    },
    {
      id: '2',
      name: 'Financial Reports',
      description: 'Financial statements and budgets',
      documentCount: 3,
      createdAt: new Date().toISOString()
    },
    {
      id: '3',
      name: 'Legal Documents',
      description: 'Contracts and legal paperwork',
      documentCount: 2,
      createdAt: new Date().toISOString()
    }
  ]);
});

// Mock files endpoint
app.get('/api/files', (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer mock-jwt-token')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  res.json({
    documents: [
      {
        id: '1',
        originalName: 'sample-document.pdf',
        fileSize: 1024000,
        mimeType: 'application/pdf',
        category: '1',
        description: 'Sample document for testing',
        tags: ['sample', 'test'],
        uploadedAt: new Date().toISOString()
      }
    ],
    total: 1,
    page: 1,
    totalPages: 1
  });
});

// Mock file upload
app.post('/api/files/upload', (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer mock-jwt-token')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  res.json({
    id: 'mock-file-' + Date.now(),
    message: 'File uploaded successfully (mock)',
    fileName: 'uploaded-file.pdf'
  });
});

// Catch all
app.use('*', (req, res) => {
  res.status(404).json({
    error: {
      code: 'NOT_FOUND',
      message: 'Endpoint not found'
    }
  });
});

// Export for Lambda
module.exports.handler = serverless(app);